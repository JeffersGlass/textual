from textual.app import App


class ExampleApp(App):
    pass


if __name__ == "__main__":
    app = ExampleApp()
    app.run()
