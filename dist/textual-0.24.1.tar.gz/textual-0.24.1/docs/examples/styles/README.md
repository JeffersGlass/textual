These are the examples from the documentation, used to generate screenshots.

You can run them with the textual CLI.

For example:

```
textual run text_style.py
```
