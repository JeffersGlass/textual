import sys

from ._run import run

run(sys.argv[1], sys.argv[1:])
