from .demo import DemoApp

if __name__ == "__main__":
    app = DemoApp()
    app.run()
